<?php 

date_default_timezone_set('Asia/Kuwait');

echo  date('Y-m-d H:i:s' , time()) ;
 

?>
<?php
include "connect.php" ;

  // sendNotifySpecificUser("9" , "اهلا" , "حنان"  , "id" , "name" ) ; // 9 = userwael
 // sendNotifySpecificTaxi("6" , "اهلا" , "حنان"  , "id" , "name"  ) ; // 6 merft taxi
//  sendNotifySpecificRes("1" , "اهلا" , "حنان"  , "id" , "name" ) ;  // wael res


  // insertTokenRes("1" , "1111111111111111111111") ;

  // insertTokenUser("9" , "222222222222222222222222") ;

   // insertTokenTaxi("6" ,"aaaaaaaaaaaaaaaaaaaaaaa" ) ;

   // deleteTokenTaxi("6" ,"aaaaaaaaaaaaaaaaaaaaaaa") ;

  //  sendNotifyEveryUser("delivery" , "title" , "wael") ; 

  // insertNotifyEveryUserInDatabase("wa" , "ww" , 0 ) ; 

  getTokenByPhone("11122");


?>

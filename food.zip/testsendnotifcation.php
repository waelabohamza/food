<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <style>
      input {
        display: block;
        margin : 10px ;
        padding : 6px 10px ;
        border: solid 1px #aaa
      }
    </style>
  </head>
  <body>
      <form class="" action="sendmail.php" method="post">
        <input type="text" name="email"  />
        <input type="text" name="title"  />
        <input type="text" name="content" />
         <input type="submit"  value="sendmail">
      </form>
  </body>
</html>
